<!--<h1>Hello from create view</h1>-->

<?php
foreach ($products as $product){
    echo $product->Name;
}
