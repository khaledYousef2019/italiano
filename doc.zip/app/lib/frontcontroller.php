<?php


namespace PHPMVC\LIB;


use PHPMVC\Controllers\AbstractController;
use PHPMVC\LIB\Template\Template;

class FrontController extends AbstractController
{
    protected $_controller = "index";
    protected $_action = "default";
    protected $_params = array();
    protected $_template;
    protected $_language;

    const NOT_FOUND_CONTROLLER = 'PHPMVC\Controllers\\NotFoundController';
    const NOT_FOUND_ACTION = 'notFoundAction';

    public function __construct(Template $template,Languages $language){
        $this->_parseUrl();
        $this->_template = $template;
        $this->_language = $language;
    }
    public function _parseUrl(){
        // parsing url to determine controller and action
        $url = explode('/',trim(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH),"/"),3);
        if (isset($url[0]) && $url[0] != ''){$this->_controller = $url[0];}
        if (isset($url[1]) && $url[1] != ''){$this->_action = $url[1];}
        if (isset($url[2]) && $url[2] != ''){$this->_params=explode('/',$url[2]);}

    }

    public function dispatch(){
        $controllerClassName = 'PHPMVC\Controllers\\'.ucfirst($this->_controller)."Controller";
        $actionName = $this->_action."Action";
        if(!class_exists($controllerClassName) || !method_exists($controllerClassName,$actionName)){
            $controllerClassName = self::NOT_FOUND_CONTROLLER;
            $this->_action = $actionName = self::NOT_FOUND_ACTION;
        }
        $controller = new $controllerClassName();
        $controller->setController($this->_controller);
        $controller->setAction($this->_action);
        $controller->setParams($this->_params);
        $controller->setTemplate($this->_template);
        $controller->setLanguage($this->_language);
        $controller->$actionName();
//        echo "<pre>";var_dump($this);
    }

}