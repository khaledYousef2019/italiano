<?php


namespace PHPMVC\LIB\Template;


class Template
{
    use TemplateHelper;
    private $_templateParts;
    private $_action_view;
    private $_data;

    public function __construct(array $parts){
        $this->_templateParts = $parts;
    }

    public function setActionView($path){
        $this->_action_view = $path;
    }
    public function setAppData($data){
        $this->_data = $data;
    }

    private function renderTemplateHeaderStart(){
        extract($this->_data);
        require_once TEMPLATE_PATH . "templateheaderstart.php";
    }
    private function renderTemplateHeaderEnd(){
        require_once TEMPLATE_PATH . "templateheaderend.php";
    }
    private function renderTemplateFooter(){
        require_once TEMPLATE_PATH . "templatefooter.php";
    }
    private function renderTemplateBlocks(){
        if (!array_key_exists('template',$this->_templateParts)){
            trigger_error('Sorry you have to define \'template\' key ');
        }else{
            if (!empty($this->_templateParts['template'])){
                foreach ($this->_templateParts['template'] as $partKey => $partFile){
                    extract($this->_data);
                    if ($partKey == ":view"){
                        require_once $this->_action_view;
                    }else{
                        require_once $partFile;
                    }
                }
            }
        }
    }
    private function renderHeaderResources(){
        $output = '';
        if (!array_key_exists('header_resources',$this->_templateParts)){
            trigger_error('Sorry you have to define \'header_resources\' key ');
        }else{
            if (!empty($this->_templateParts['header_resources'])){
                foreach ($this->_templateParts['header_resources']['css'] as $partKey => $partFile){
                        $output .= '<link type="text/css" rel="stylesheet" href="'.$partFile.'">';

                }
            }
            if (!empty($this->_templateParts['header_resources']['js'])){
                foreach ($this->_templateParts['header_resources']['js'] as $partKey => $partFile){
                        $output .= "<script src='".$partFile."'></script>";
                }
                $output.= "<script>tinymce.init({selector:'textarea'});</script>";
            }
        }
        echo $output;
    }

    private function renderFooterResources(){
        $output = '';
        if (!array_key_exists('footer_resources',$this->_templateParts)){
            trigger_error('Sorry you have to define \'header_resources\' key ');
        }else{

            if (!empty($this->_templateParts['footer_resources'])){
                foreach ($this->_templateParts['footer_resources'] as $partKey => $partFile){
                    $output .= "<script src='".$partFile."'></script>";
                }
            }
        }
//        $output.= "  <script>
//    tinymce.init({
//      selector: 'textarea',
//      plugins: 'a11ychecker advcode casechange formatpainter linkchecker autolink lists checklist media mediaembed pageembed permanentpen powerpaste table advtable tinycomments tinymcespellchecker',
//      toolbar: 'a11ycheck addcomment showcomments casechange checklist code formatpainter pageembed permanentpen table',
//      toolbar_mode: 'floating',
//      tinycomments_mode: 'embedded',
//      tinycomments_author: 'Author name',
//   });
//  </script>";
        echo $output;
    }

    public function renderApp(){
        if ($this->_action_view !=  "/var/www/acc-system.com/app/config/../views//receipt/default.view.php") {
        $this->renderTemplateHeaderStart();
        $this->renderHeaderResources();
        $this->renderTemplateHeaderEnd();
        $this->renderTemplateBlocks();

        $this->renderFooterResources();
        $this->renderTemplateFooter();
        }else{
            require_once $this->_action_view;
        }
//            var_dump($this->_action_view);
        }

}