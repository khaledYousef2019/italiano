<?php

$_['title'] = 'Privileges';
$_['text_header'] = 'Privileges';
$_['text_new_item'] = 'New Privilege';
$_['text_table_privilege'] = 'The Privilege';
$_['text_table_control'] = 'Control';
$_['text_table_control_delete_confirm'] = 'Would you like to delete the privilege?';