<?php

$_['text_legend'] = 'Privilege Details';
$_['text_label_privilege_title'] = 'Privilege Title';
$_['text_label_privilege_url'] = 'Privilege URL';
$_['text_label_save'] = 'Save';
