<?php

$_['title'] = 'Edit privilege details';
