<?php

$_['title'] = 'Create new privilege';
