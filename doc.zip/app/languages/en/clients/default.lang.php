<?php

$_['title'] = 'العملاء';
$_['text_header'] = 'العملاء';
$_['text_new_item'] = 'عميل جديد';
$_['text_table_name'] = 'إسم العميل';
$_['text_table_email'] = 'البريد الالكتروني';
$_['text_table_phone_number'] = 'رقم الهاتف';
$_['text_table_control'] = 'التحكم';
$_['text_table_control_delete_confirm'] = 'هل تود حذف العملاء من قاعدة البيانات؟';