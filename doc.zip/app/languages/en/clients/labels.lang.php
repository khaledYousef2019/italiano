<?php

$_['text_legend'] = 'بيانات العميل';
$_['text_label_Name'] = 'إسم العميل';
$_['text_label_PhoneNumber'] = 'رقم الهاتف';
$_['text_label_Email'] = 'البريد الالكتروني';
$_['text_label_Address'] = 'العنوان';
$_['text_label_save'] = 'حفظ';