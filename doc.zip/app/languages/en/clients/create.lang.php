<?php

$_['title'] = 'عميل جديد';
$_['text_header'] = 'عميل جديد';