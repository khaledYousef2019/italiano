<?php

$_['message_create_success'] = 'تم حفظ العميل بنجاح';
$_['message_create_failed'] = 'خطأ في حفظ العميل';
$_['message_delete_success'] = 'تم حذف العميل بنجاح';
$_['message_delete_failed'] = 'خطأ في حذف العميل';