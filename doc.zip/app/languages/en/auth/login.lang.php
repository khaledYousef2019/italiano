<?php

$_['title'] = 'Login to the application';
$_['login_header'] = 'Login to the application';
$_['login_ucname'] = 'Username';
$_['login_ucpwd'] = 'Password';
$_['login_button'] = 'Login';

$_['text_user_disabled'] = 'Sorry this account has been disabled by the administration';
$_['text_user_not_found'] = 'Either Username or Password is incorrect';