<?php

$_['text_legend'] = 'القسم التابع له المنتج';
$_['text_label_Name'] = 'Name';
$_['text_label_Content'] = 'Letter';
//$_['text_label_price'] = 'price';
//$_['text_label_Unit'] = 'وحدة قياس المنتج';
//$_['text_label_Image'] = 'صورة المنتج';
$_['text_label_save'] = 'حفظ';
