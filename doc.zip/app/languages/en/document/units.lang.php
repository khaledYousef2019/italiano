<?php

$_['text_unit_1'] = 'كيلو';
$_['text_unit_2'] = 'كارتون';
$_['text_unit_3'] = 'متر';
$_['text_unit_4'] = 'قطعة';