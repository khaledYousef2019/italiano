<?php

$_['message_create_success'] = 'تم حفظ المنتج بنجاح';
$_['message_create_failed'] = 'خطأ في حفظ المنتج';
$_['message_delete_success'] = 'تم حذف المنتج بنجاح';
$_['message_delete_failed'] = 'خطأ في حذف المنتج';