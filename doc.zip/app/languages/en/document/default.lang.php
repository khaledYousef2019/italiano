<?php

$_['title'] = 'products';
$_['text_header'] = 'products';
$_['text_new_item'] = 'new product';
$_['text_table_name'] = 'Document Name';
$_['text_table_content'] = 'Document Content';
$_['text_table_serial'] = 'Serial Number';
$_['text_table_control'] = 'control';
$_['text_table_control_delete_confirm'] = 'do you confirm to delete document ?';