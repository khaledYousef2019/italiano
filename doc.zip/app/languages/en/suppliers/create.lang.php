<?php

$_['title'] = 'مورد جديد';
$_['text_header'] = 'مورد جديد';