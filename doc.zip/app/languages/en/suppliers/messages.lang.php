<?php

$_['message_create_success'] = 'تم حفظ المورد بنجاح';
$_['message_create_failed'] = 'خطأ في حفظ المورد';
$_['message_delete_success'] = 'تم حذف المورد بنجاح';
$_['message_delete_failed'] = 'خطأ في حذف المورد';