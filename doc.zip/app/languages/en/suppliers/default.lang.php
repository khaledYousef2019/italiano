<?php

$_['title'] = 'الموردين';
$_['text_header'] = 'الموردين';
$_['text_new_item'] = 'مورد جديد';
$_['text_table_name'] = 'إسم المورد';
$_['text_table_email'] = 'البريد الالكتروني';
$_['text_table_phone_number'] = 'رقم الهاتق';
$_['text_table_control'] = 'التحكم';
$_['text_table_control_delete_confirm'] = 'هل تود حذف المورد من قاعدة البيانات؟';