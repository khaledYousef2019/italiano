<?php

$_['text_legend'] = 'User Details';
$_['text_label_Username'] = 'Username';
$_['text_label_FirstName'] = 'First Name';
$_['text_label_LastName'] = 'Last Name';
$_['text_label_Password'] = 'Password';
$_['text_label_CPassword'] = 'Confirm Password';
$_['text_label_Email'] = 'Email';
$_['text_label_CEmail'] = 'Confirm Email';
$_['text_label_PhoneNumber'] = 'Phone Number';
$_['text_user_GroupId'] = 'Users Groups';
$_['text_label_save'] = 'Save';