<?php

$_['title'] = 'Users and Privileges';
$_['text_header'] = 'Users and Privileges';
$_['text_new_item'] = 'New User';
$_['text_table_username'] = 'Username';
$_['text_table_group'] = 'User Group';
$_['text_table_email'] = 'Email';
$_['text_table_subscription_date'] = 'Subscription Date';
$_['text_table_last_login'] = 'Last Logged In';
$_['text_table_control'] = 'Control';
$_['text_table_control_delete_confirm'] = 'Would you like to delete the user from the database?';