<?php

$_['title'] = 'Modifying user details';
$_['text_header'] = 'Modifying user details';