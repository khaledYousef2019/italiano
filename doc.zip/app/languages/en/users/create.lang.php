<?php

$_['title'] = 'New user';
$_['text_header'] = 'New user';