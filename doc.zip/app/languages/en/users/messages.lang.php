<?php

$_['message_create_success'] = 'User saved successfully';
$_['message_create_failed'] = 'Error saving the user';
$_['message_delete_success'] = 'User deleted successfully';
$_['message_delete_failed'] = 'Error deleting user';
$_['message_user_exists'] = 'Username already exists';
$_['message_email_exists'] = 'Email already exists';