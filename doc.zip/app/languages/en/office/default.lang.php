<?php

$_['title'] = 'Offices';
$_['text_add_office'] = 'Add new office';
$_['text_table_office_name'] = 'Office name';
$_['text_table_office_email'] = 'Email';
$_['text_table_office_code'] = 'Code';
$_['text_table_office_lastlogin'] = 'Last Login';
$_['text_table_office_tax'] = 'Tax (%)';
$_['text_table_control'] = 'Control';
$_['text_delete_confirm'] = 'Do you want to delete this record?';