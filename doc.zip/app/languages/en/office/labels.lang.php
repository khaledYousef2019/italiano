<?php

$_['text_office_details'] = 'Office Details';
$_['text_label_name'] = 'Name';
$_['text_label_email'] = 'Email';
$_['text_label_password'] = 'Password';
$_['text_label_gender_male'] = 'Male';
$_['text_label_gender_female'] = 'Female';
$_['text_label_code'] = 'Code';
$_['text_label_salary'] = 'Salary';
$_['text_label_tax'] = 'Tax';
$_['text_label_choose_office_type'] = 'Choose office type';
$_['text_label_type_part_time'] = 'Part Time Office';
$_['text_label_type_full_time'] = 'Full Time Office';
$_['text_label_os'] = 'Operating Systems in which office can use';
$_['text_label_os_windows'] = 'Windows';
$_['text_label_os_linux'] = 'Linux';
$_['text_label_os_mac'] = 'Mac OS';
$_['text_label_notes'] = 'Notes';
$_['text_label_save'] = 'Save';