<?php

$_['text_legend'] = 'القسم التابع له المنتج';
$_['text_label_Name'] = 'إسم المنتج';
$_['text_label_Quantity'] = 'الكمية المتاحة';
$_['text_label_BuyPrice'] = 'سعر الشراء';
$_['text_label_SellPrice'] = 'سعر البيع';
$_['text_label_Unit'] = 'وحدة قياس المنتج';
$_['text_label_Image'] = 'صورة المنتج';
$_['text_label_save'] = 'حفظ';
