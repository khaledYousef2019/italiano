<?php

$_['title'] = 'products';
$_['text_header'] = 'products';
$_['text_new_item'] = 'new product';
$_['text_table_name'] = 'product Name';
$_['text_table_category'] = 'Product Category';
$_['text_table_small_price'] = 'price (small)';
$_['text_table_medium_price'] = 'price (medium)';
$_['text_table_large_price'] = 'price (large)';
$_['text_table_control'] = 'control';
$_['text_table_control_delete_confirm'] = 'do you confirm to delete product ?';
$_['text_label_address'] = 'Client Address';
$_['text_label_phone_number'] = 'Phone number';
$_['text_label_delivery'] = 'delivery Service';
