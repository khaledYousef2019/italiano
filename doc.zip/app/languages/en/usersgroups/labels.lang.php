<?php

$_['text_legend'] = 'Group Details';
$_['text_label_group_title'] = 'Group Name';
$_['text_label_privileges'] = 'Group Privileges';
$_['text_label_save'] = 'Save';
