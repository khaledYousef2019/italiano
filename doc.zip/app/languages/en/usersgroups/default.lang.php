<?php

$_['title'] = 'Users Groups';
$_['text_header'] = 'Users Groups';
$_['text_new_item'] = 'New User Group';
$_['text_table_group_name'] = 'Group Name';
$_['text_table_control'] = 'Control';
$_['text_table_control_delete_confirm'] = 'Would you like to delete this Users Group?';