<?php

$_['title'] = 'Categories';
$_['text_header'] = 'Categories';
$_['text_new_item'] = 'New Category';
$_['text_table_group_name'] = 'Product Category Name';
$_['text_table_group_image'] = 'Product Category Image';
$_['text_table_control'] = 'Control';
$_['text_table_control_delete_confirm'] = 'Do you Confirm to delete category ?';