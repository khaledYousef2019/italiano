<?php

$_['text_legend'] = 'بيانات القسم';
$_['text_label_category_title'] = 'اسم قسم المنتجات';
$_['text_label_category_image'] = 'صورة قسم المنتجات';
$_['text_label_save'] = 'حفظ';
