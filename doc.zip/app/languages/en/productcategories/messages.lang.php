<?php

$_['message_create_success'] = 'تم حفظ القسم بنجاح';
$_['message_create_failed'] = 'خطأ في حفظ القسم';
$_['message_delete_success'] = 'تم حذف القسم بنجاح';
$_['message_delete_failed'] = 'خطأ في حذف القسم';