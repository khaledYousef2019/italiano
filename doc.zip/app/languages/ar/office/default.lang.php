<?php

$_['title'] = 'الموظفين';
$_['text_add_office'] = 'إضافة موظف جديد';
$_['text_table_office_name'] = 'إسم الموظف';
$_['text_table_office_age'] = 'العمر';
$_['text_table_office_address'] = 'العنوان';
$_['text_table_office_salary'] = 'المرتب';
$_['text_table_office_tax'] = 'الضريبة (%)';
$_['text_table_control'] = 'التحكم';
$_['text_delete_confirm'] = 'هل ترغب في حذف الموظف؟';