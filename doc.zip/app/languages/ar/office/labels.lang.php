<?php

$_['text_office_details'] = 'بيانات الموظف';
$_['text_label_name'] = 'الإسم';
$_['text_label_address'] = 'العنوان';
$_['text_label_gender'] = 'النوع';
$_['text_label_gender_male'] = 'ذكر';
$_['text_label_gender_female'] = 'أنثى';
$_['text_label_age'] = 'العمر';
$_['text_label_salary'] = 'الراتب';
$_['text_label_tax'] = 'الضريبة (%)';
$_['text_label_choose_office_type'] = 'إختار نوع الوظيفة';
$_['text_label_type_part_time'] = 'دوام جزئي';
$_['text_label_type_full_time'] = 'دوام كامل';
$_['text_label_os'] = 'أنظمة التشغيل التي يمكن استخدامها';
$_['text_label_os_windows'] = 'ويندوز';
$_['text_label_os_linux'] = 'لينوكس';
$_['text_label_os_mac'] = 'ماك';
$_['text_label_notes'] = 'ملاحظات';
$_['text_label_save'] = 'حفظ';