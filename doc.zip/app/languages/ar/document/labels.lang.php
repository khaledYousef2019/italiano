<?php

$_['text_legend'] = 'بيانات المنتج';
$_['text_label_Name'] = 'إسم المنتج';
$_['text_label_CategoryId'] = 'القسم التابع له المنتج';
$_['text_label_Quantity'] = 'الكمية المتاحة';
$_['text_label_price'] = 'السعر';
$_['text_label_Unit'] = 'وحدة قياس المنتج';
$_['text_label_Image'] = 'صورة المنتج';
$_['text_label_save'] = 'حفظ';
