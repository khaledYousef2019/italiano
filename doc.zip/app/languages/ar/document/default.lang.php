<?php

$_['title'] = 'المنتجات';
$_['text_header'] = 'المنتجات';
$_['text_new_item'] = 'منتج جديد';
$_['text_table_name'] = 'إسم المنتج';
$_['text_table_category'] = 'القسم التابع له';
$_['text_table_price'] = 'السعر';
$_['text_table_control'] = 'التحكم';
$_['text_table_control_delete_confirm'] = 'هل تود حذف المنتج؟';