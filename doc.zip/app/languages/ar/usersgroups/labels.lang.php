<?php

$_['text_legend'] = 'بيانات المجموعة';
$_['text_label_group_title'] = 'اسم المجموعة';
$_['text_label_privileges'] = 'الصلاحيات التابعة لهذه المجموعة';
$_['text_label_save'] = 'حفظ';
