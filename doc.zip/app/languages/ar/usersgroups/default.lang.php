<?php

$_['title'] = 'مجموعات المستخدمين';
$_['text_header'] = 'مجموعات المستخدمين';
$_['text_new_item'] = 'مجموعة جديدة';
$_['text_table_group_name'] = 'إسم المجموعة';
$_['text_table_control'] = 'التحكم';
$_['text_table_control_delete_confirm'] = 'هل تود حذف المجموعة؟';