<?php

$_['title'] = 'المنتجات';
$_['text_header'] = 'المنتجات';
$_['text_new_item'] = 'فاتوره جديده';
$_['text_table_name'] = 'إسم المنتج';
$_['text_table_category'] = 'القسم التابع له';
$_['text_table_price'] = 'سعر (حجم صغير)';
$_['text_table_control'] = 'التحكم';
$_['text_table_control_delete_confirm'] = 'هل تود حذف المنتج؟';
$_['text_label_address'] = 'عنوان العميل';
$_['text_label_phone_number'] = 'رقم هاتف العميل';
$_['text_label_delivery'] = 'خدمة التوصيل';