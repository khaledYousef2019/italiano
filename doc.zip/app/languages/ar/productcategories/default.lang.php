<?php

$_['title'] = 'أقسام المنتجات';
$_['text_header'] = 'أقسام المنتجات';
$_['text_new_item'] = 'قسم منتجات جديدة';
$_['text_table_group_name'] = 'إسم قسم المنتجات';
$_['text_table_group_image'] = 'صورة قسم المنتجات';
$_['text_table_control'] = 'التحكم';
$_['text_table_control_delete_confirm'] = 'هل تود حذف القسم؟';