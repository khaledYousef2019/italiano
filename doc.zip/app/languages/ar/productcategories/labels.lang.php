<?php

$_['text_legend'] = 'بيانات القسم';
$_['text_label_Name'] = 'اسم قسم المنتجات';
$_['text_label_Image'] = 'صورة قسم المنتجات';
$_['text_label_save'] = 'حفظ';
