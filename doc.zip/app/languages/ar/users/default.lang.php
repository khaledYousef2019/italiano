<?php

$_['title'] = 'المستخدمين و الصلاحيات';
$_['text_header'] = 'المستخدمين و الصلاحيات';
$_['text_new_item'] = 'مستخدم جديد';
$_['text_table_username'] = 'إسم المستخدم';
$_['text_table_group'] = 'المجموعة التابع لها';
$_['text_table_email'] = 'البريد الالكتروني';
$_['text_table_subscription_date'] = 'تاريخ الانضمام';
$_['text_table_last_login'] = 'اخر وقت دخول';
$_['text_table_control'] = 'التحكم';
$_['text_table_control_delete_confirm'] = 'هل تود حذف المستخدم من قاعدة البيانات؟';