<?php

$_['text_legend'] = 'بيانات المستخدم';
$_['text_label_Username'] = 'إسم المستخدم';
$_['text_label_FirstName'] = 'الاسم الاول';
$_['text_label_LastName'] = 'الاسم الاخير';
$_['text_label_Password'] = 'كلمة المرور';
$_['text_label_CPassword'] = 'تأكيد كلمة المرور';
$_['text_label_Email'] = 'البريد الالكتروني';
$_['text_label_CEmail'] = 'تأكيد البريد الالكتروني';
$_['text_label_PhoneNumber'] = 'رقم الهاتف';
$_['text_user_GroupId'] = 'مجموعات المستخدمين';
$_['text_label_save'] = 'حفظ';