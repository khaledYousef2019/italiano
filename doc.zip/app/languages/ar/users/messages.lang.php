<?php

$_['message_create_success'] = 'تم حفظ المستخدم بنجاح';
$_['message_create_failed'] = 'خطأ في حفظ المستخدم';
$_['message_delete_success'] = 'تم حذف المستخدم بنجاح';
$_['message_delete_failed'] = 'خطأ في حذف المستخدم';
$_['message_user_exists'] = 'المستخدم مسجل بالفعل';
$_['message_email_exists'] = 'البريد الالكتروني مسجل بالفعل';