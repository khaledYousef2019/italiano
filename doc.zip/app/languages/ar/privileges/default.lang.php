<?php

$_['title'] = 'الصلاحيات';
$_['text_header'] = 'الصلاحيات';
$_['text_new_item'] = 'صلاحية جديدة';
$_['text_table_privilege'] = 'الصلاحية';
$_['text_table_control'] = 'التحكم';
$_['text_table_control_delete_confirm'] = 'هل تود حذف الصلاحية؟';