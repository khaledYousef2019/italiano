<?php

$_['text_legend'] = 'بيانات الصلاحية';
$_['text_label_privilege_title'] = 'اسم الصلاحية';
$_['text_label_privilege_url'] = 'رابط الصلاحية';
$_['text_label_save'] = 'حفظ';
